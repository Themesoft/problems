/* 
 * Problems Banks - Custom Javascripts
 */

$(document).ready(function () {
    
});